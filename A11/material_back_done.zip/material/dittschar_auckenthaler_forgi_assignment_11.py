import os


fname = "auckenthaler_dittschar_structures.txt"
os.system("RNAplot < " + fname)